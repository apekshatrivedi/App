package in.amylife.app.amylife;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;




public class DetailsActivity extends AppCompatActivity {

    String name, status;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_details);



        TextView txtProduct = (TextView) findViewById(R.id.product_label);
        Switch Switch = (Switch) findViewById(R.id.switch1);
        TextView mirror = (TextView)findViewById(R.id.MirrorText);

        Intent i = getIntent();
        // getting attached intent data
        name = i.getStringExtra("name");
        status = i.getStringExtra("status");
        Log.e("Status:", status);
        // displaying selected product name
        txtProduct.setText(name);

        if (status.equals("1")) {
            Switch.setChecked(true);
            mirror.setVisibility(View.GONE);
        }
        else if (status.equals("0")) {


            Switch.setChecked(false);
            mirror.setVisibility(View.GONE);
        }
        else {
            Toast.makeText(this, "SmartMirror", Toast.LENGTH_SHORT).show();
            //Switch.setChecked(false);

            Switch.setVisibility(View.GONE);
            mirror.setVisibility(View.VISIBLE);
            mirror.setText(status);
        }


        Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton cb, boolean on) {
                if (on) {
                    status = "1";
                    new sendStatus().execute(name, status);


                } else {
                    status = "0";
                    new sendStatus().execute(name, status);


                }


            }
        });
    }


}