package in.amylife.app.amylife;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import devlight.io.library.ntb.NavigationTabBar;

public class IpAddActivity extends AppCompatActivity {

    public static String ipaddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ipadd);

        initUI();

        EditText ip1 = (EditText) findViewById(R.id.ipadd1);
        EditText ip2 = (EditText) findViewById(R.id.ipadd2);
        EditText ip3 = (EditText) findViewById(R.id.ipadd3);
        EditText ip4 = (EditText) findViewById(R.id.ipadd4);

        String ipadd1=ip1.getText().toString();
        String ipadd2=ip2.getText().toString();
        String ipadd3=ip3.getText().toString();
        String ipadd4=ip4.getText().toString();


        //ipaddress="http://192.168.43.77";
        ipaddress="http://"+ipadd1+"."+ipadd2+"."+ipadd3+"."+ipadd4;


    }



    private void initUI() {


        final NavigationTabBar ntbSample6 = (NavigationTabBar) findViewById(R.id.ntb_sample_6);
        final int bgColor = Color.parseColor("#423752");
        final ArrayList<NavigationTabBar.Model> models6 = new ArrayList<>();
        models6.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.ic_ipadd), bgColor
                ).build()
        );
        models6.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.ic_control), bgColor
                ).build()
        );
        models6.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.ic_add), bgColor
                ).build()
        );

        ntbSample6.setModels(models6);




        ntbSample6.setOnTabBarSelectedIndexListener(new NavigationTabBar.OnTabBarSelectedIndexListener() {
            @Override
            public void onStartTabSelected(final NavigationTabBar.Model model, final int index) {

            }

            @Override
            public void onEndTabSelected(final NavigationTabBar.Model model, final int index) {
                Toast.makeText(IpAddActivity.this, String.format("onEndTabSelected #%d", index), Toast.LENGTH_SHORT).show();

                Intent i;

                if(index==1)
                {
                    i = new Intent(IpAddActivity.this,DevicesActivity.class);
                    startActivity(i);
                }

                if(index==2)
                {
                    i = new Intent(IpAddActivity.this,AddDeviceActivity.class);
                    startActivity(i);

                }


            }
        });



    }
}
